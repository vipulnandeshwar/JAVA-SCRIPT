var a=10
console.log(a);
console.log(typeof a);

var b=10.56
console.log(b);
console.log(typeof b);

var c=-85
console.log(c);
console.log(typeof c);

let q=-95.25
console.log(q);
console.log(typeof q);

var d=1563248632
console.log(d);
console.log(typeof d);

let s=10n
console.log(s);
console.log(typeof s);

let w=-10n
console.log(w);
console.log(typeof w);

let t='i am a dev since'+8+'yrs'
console.log(t);
console.log(typeof t);

let y="i am a dev since"+a+"yrs"
console.log(y);
console.log(typeof y);

let u=`i ' am 
                a dev since
${a}    yrs  ${a}`
console.log(u);
console.log(typeof u);

let b1=true
console.log(b1);
console.log(typeof b1);

let c1=false
console.log(c1);
console.log(typeof c1);

let f
console.log(false);
console.log(typeof f);

let k= undefined
console.log(k);
console.log(typeof k);

let r=50
console.log(r);
console.log(typeof r);
r=null
console.log(r);
console.log(typeof r);

let g=NaN
console.log(g);
console.log(typeof g);

let f1=10
console.log(isNaN(f1));

let h=Symbol("h1")
console.log(h);
console.log(h.description);
console.log(typeof h);
